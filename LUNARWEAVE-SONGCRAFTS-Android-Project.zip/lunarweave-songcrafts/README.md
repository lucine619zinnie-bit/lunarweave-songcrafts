# LUNARWEAVE SONGCRAFTS — Android project

This upgrade preserves the original Android application ID (`com.lunarweave.arcanesongcraft`) and WebView-based app, including its existing song-concept randomizer, studio blueprint, local Vault, clipboard bridge, and Downloads export bridge.

## Build a debug APK

1. Open this folder in Android Studio with JDK 17 and Android SDK 35 installed.
2. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, push this project to a GitHub repository and run the included GitHub Actions workflow.

The app uses internet access for Tailwind, Lucide, and Google Fonts CDN resources. Saved concepts remain in WebView local storage on the device.
